/*
 *   Camera.cpp
 *
 *   Author:
 *
 */


#include "Camera.h"

using namespace Robot;

int Camera::WIDTH  = 320;
int Camera::HEIGHT = 240;

